import 'package:flutter/material.dart';
import 'package:flutterapp/elearningapp/generatedassignmentsdetailedscreen1widget/GeneratedAssignmentsDetailedScreen1Widget.dart';
import 'package:flutterapp/elearningapp/generatedassignmentsscreen1widget/GeneratedAssignmentsScreen1Widget.dart';
import 'package:flutterapp/elearningapp/generatedcallaccepted1widget/GeneratedCallAccepted1Widget.dart';
import 'package:flutterapp/elearningapp/generatedcallingscreen1widget/GeneratedCallingScreen1Widget.dart';
import 'package:flutterapp/elearningapp/generatedcamera1widget/GeneratedCamera1Widget.dart';
import 'package:flutterapp/elearningapp/generatedchathistory1widget/GeneratedChatHistory1Widget.dart';
import 'package:flutterapp/elearningapp/generatedchat1widget/GeneratedChat1Widget.dart';
import 'package:flutterapp/elearningapp/generateddialin1widget/GeneratedDialin1Widget.dart';
import 'package:flutterapp/elearningapp/generatedhomescreen1widget/GeneratedHomeScreen1Widget.dart';
import 'package:flutterapp/elearningapp/generatedloadingscreen11widget/GeneratedLoadingScreen11Widget.dart';
import 'package:flutterapp/elearningapp/generatedloadingscreen1widget/GeneratedLoadingScreen1Widget.dart';
import 'package:flutterapp/elearningapp/generatedloginen1widget/GeneratedLoginEN1Widget.dart';
import 'package:flutterapp/elearningapp/generatedloginid1widget/GeneratedLoginID1Widget.dart';
import 'package:flutterapp/elearningapp/generatedpicture1widget/GeneratedPicture1Widget.dart';
import 'package:flutterapp/elearningapp/generatedvoicemessages1widget/GeneratedVoiceMessages1Widget.dart';
import 'package:flutterapp/elearningapp/generatedwrite1widget/GeneratedWrite1Widget.dart';
import 'package:flutterapp/elearningapp/generatedyourworkdetailedscreen1widget/GeneratedYourWorkDetailedScreen1Widget.dart';
import 'package:flutterapp/elearningapp/generatedimage24widget/GeneratedImage24Widget.dart';

void main() {
  runApp(ELEARNINGApp());
}

class ELEARNINGApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedLoadingScreen1Widget',
      routes: {
        '/GeneratedAssignmentsDetailedScreen1Widget': (context) =>
            GeneratedAssignmentsDetailedScreen1Widget(),
        '/GeneratedAssignmentsScreen1Widget': (context) =>
            GeneratedAssignmentsScreen1Widget(),
        '/GeneratedCallAccepted1Widget': (context) =>
            GeneratedCallAccepted1Widget(),
        '/GeneratedCallingScreen1Widget': (context) =>
            GeneratedCallingScreen1Widget(),
        '/GeneratedCamera1Widget': (context) => GeneratedCamera1Widget(),
        '/GeneratedChatHistory1Widget': (context) =>
            GeneratedChatHistory1Widget(),
        '/GeneratedChat1Widget': (context) => GeneratedChat1Widget(),
        '/GeneratedDialin1Widget': (context) => GeneratedDialin1Widget(),
        '/GeneratedHomeScreen1Widget': (context) =>
            GeneratedHomeScreen1Widget(),
        '/GeneratedLoadingScreen11Widget': (context) =>
            GeneratedLoadingScreen11Widget(),
        '/GeneratedLoadingScreen1Widget': (context) =>
            GeneratedLoadingScreen1Widget(),
        '/GeneratedLoginEN1Widget': (context) => GeneratedLoginEN1Widget(),
        '/GeneratedLoginID1Widget': (context) => GeneratedLoginID1Widget(),
        '/GeneratedPicture1Widget': (context) => GeneratedPicture1Widget(),
        '/GeneratedVoiceMessages1Widget': (context) =>
            GeneratedVoiceMessages1Widget(),
        '/GeneratedWrite1Widget': (context) => GeneratedWrite1Widget(),
        '/GeneratedYourWorkDetailedScreen1Widget': (context) =>
            GeneratedYourWorkDetailedScreen1Widget(),
        '/GeneratedImage24Widget': (context) => GeneratedImage24Widget(),
      },
    );
  }
}
